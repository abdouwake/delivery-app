package deliveryapp.ordermanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
